from WMCore.Configuration import Configuration
config = Configuration()

config.section_('General')
config.General.transferLogs = False
config.General.transferOutputs = True
config.General.workArea = 'crab_projects_dump_TTbar_LHE_v1'
config.General.requestName = 'dump_LHEvent_v1'

config.section_('JobType')
config.JobType.psetName = 'dump.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True

config.section_('Data')
config.Data.inputDataset = '/TTToHadronic_TuneCP5_13TeV-powheg-pythia8/RunIIAutumn18MiniAOD-102X_upgrade2018_realistic_v15-v1/MINIAODSIM'
config.Data.outputDatasetTag = 'RunIIAutumn18MiniAOD_ttbar_v1'
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.outLFNDirBase = '/store/user/sungwon/ttbar_LHE_v1'

config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
