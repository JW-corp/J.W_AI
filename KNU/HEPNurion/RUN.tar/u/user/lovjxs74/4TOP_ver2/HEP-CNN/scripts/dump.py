import FWCore.ParameterSet.Config as cms
process = cms.Process("Dump")
process.load("FWCore.MessageService.MessageLogger_cfi")
process.load("Configuration.EventContent.EventContent_cff")
#process.MessageLogger.cerr.FwkReport.reportEvery = 1000

process.source = cms.Source("PoolSource",
		    fileNames = cms.untracked.vstring(),
			    secondaryFileNames = cms.untracked.vstring()
		)
process.out = cms.OutputModule("PoolOutputModule",
								outputCommands = cms.untracked.vstring(
								'drop *',
								'keep PileupSummaryInfos_*_*_*',
								'keep GenEventInfoProduct_*_*_*',
								'keep externalLHEProducer_*_*_*',
								'keep recoGenParticles_*_*_*',
								'keep patPackedGenParticles_*_*_*',
								'keep recoGenJets_*_*_*',
								'keep recoJetFlavourInfoMatchingCollection_*_*_*',
								'keep recoGenMETs_*_*_*',
								'keep LHEEventProduct_*_*_*',
								'drop *_*_*_Dump',
								),
			    fileName = cms.untracked.string('ttbar_to_hadronic_v1.root'),
		)
process.p = cms.Path(
		)
process.outPath = cms.EndPath(process.out)
#process.source.fileNames = [ 'file:/xrootd/store/mc/RunIIFall15MiniAODv2/TT_TuneCUETP8M1_13TeV-powheg-pythia8/MINIAODSIM/PU25nsData2015v1_76X_mcRun2_asymptotic_v12_ext3-v1/00000/74BE249D-4DC2-E511-8A07-D067E5F91BA5.root']