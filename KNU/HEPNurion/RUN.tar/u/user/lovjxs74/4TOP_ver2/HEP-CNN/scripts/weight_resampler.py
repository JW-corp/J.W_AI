#!/usr/bin/env python

import tensorflow as tf
import tensorflow.keras as keras
import tensorflow.keras.layers as layers
import awkward as ak
import numpy as np
import pandas as pd
import uproot
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import glob

netarch = [128, 128]

# Defining model
seqmodel = keras.Sequential()
seqmodel.add(keras.Input(shape=(21,)))
for anet in netarch:
    seqmodel.add(layers.Dense(anet, activation=None))
    seqmodel.add(layers.LeakyReLU())
    seqmodel.add(layers.Dropout(rate=0.05)) ## dropout rate 조절
seqmodel.add(layers.Dense(1, activation='softplus'))
seqmodel.summary()

## Load file list
file_path = "/data/swkim/4top_Delphes_for_resample_ver2/*.root"
path_list = glob.glob(file_path)

## for converting data
def to_np_array(ak_array, maxN=100, pad=0):
    return ak.fill_none(ak.pad_none(ak_array, maxN, clip=True, axis=-1), pad).to_numpy()

## Load data
for idx,fName in enumerate(path_list):
    df = uproot.open(fName+':Delphes;1')
    if idx == 0:
        df_treeE = df.arrays(filter_name=["Event.Weight"],library='pd')
        df_treeJ = df.arrays(filter_name=["GenJet.PT"])
        df_treeM = df.arrays(filter_name=["GenMissingET.MET"])
    else:
        tempE = df.arrays(filter_name=["Event.Weight"],library='pd')
        tempJ = df.arrays(filter_name=["GenJet.PT"])
        tempM = df.arrays(filter_name=["GenMissingET.MET"])
        df_treeE = pd.concat([df_treeE, tempE], ignore_index = True)
        df_treeJ = ak.concatenate([df_treeJ, tempJ], axis=0)
        df_treeM = ak.concatenate([df_treeM, tempM], axis=0)


df_treeMet = pd.DataFrame(to_np_array(df_treeM['GenMissingET.MET'],maxN=1))
df_treeMet.rename(columns={0:'20'}, inplace=True)
df_treeJet = pd.DataFrame(to_np_array(df_treeJ['GenJet.PT'], maxN=20))
df_sum = pd.concat([df_treeJet, df_treeMet], axis=1)
del df_treeJ
del df_treeM
del df_treeMet
del df_treeJet

scaler_E = MinMaxScaler(feature_range=(0, 1))
input_features = pd.DataFrame(scaler_E.fit_transform(df_sum.iloc[:,:21]), columns=df_sum.columns[:21])
del df_sum

weights = df_treeE['Event.Weight']
targetweights = weights/max( weights.max(), -weights.min() )
del df_treeE

earlystopping_callback = keras.callbacks.EarlyStopping(patience=30, min_delta=1e-4)
opt = keras.optimizers.Adam(learning_rate=1e-4)
tf.debugging.set_log_device_placement(True)
with tf.device('/device:GPU:1'):
    seqmodel.compile(optimizer=opt, loss='MSE')
    seqmodel.fit(input_features, targetweights, batch_size=128, epochs=10, validation_split=0.4, callbacks=[])

seqmodel.save('./resampler_model_and_weight.h5')